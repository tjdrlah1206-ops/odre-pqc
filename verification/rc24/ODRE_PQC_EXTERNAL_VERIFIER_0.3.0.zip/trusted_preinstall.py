"""Trusted external verifier entrypoint; product code is never imported here."""
import argparse
import json
import os
import platform
import sys
from pathlib import Path

if sys.version_info[:2] != (3, 12):
    print(json.dumps({'PREINSTALL':'FAIL','ERROR':'PYTHON_3_12_REQUIRED','EXTRACTION':0,
                      'PIP_INVOKED':0,'PRODUCT_IMPORT':0,'PRODUCT_RUNTIME_LOAD':0,
                      'INIT':0,'PRODUCTION_CONTACT':0},separators=(',',':')))
    raise SystemExit(2)

from bundle_gate import IntegrityError, MAX_ARCHIVE_BYTES, require, sha, strict_json, verify_archive
from cms_gate import read_regular, verify_cms

def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--envelope', type=Path, required=True)
    parser.add_argument('--cms', type=Path, required=True)
    parser.add_argument('--trust', type=Path, required=True)
    parser.add_argument('--trust-sha256', required=True)
    parser.add_argument('--expected-bundle-sha256', required=True)
    parser.add_argument('--install-new', type=Path)
    args = parser.parse_args(argv)
    result = {'PREINSTALL': 'FAIL', 'EXTRACTION': 0, 'PIP_INVOKED': 0,
              'PRODUCT_IMPORT': 0, 'PRODUCT_RUNTIME_LOAD': 0, 'INIT': 0,
              'PRODUCTION_CONTACT': 0, 'PUBLICATION_STATUS': 'NOT_PUBLISHED'}
    try:
        trust_raw = read_regular(args.trust, 1024*1024)
        require(sha(trust_raw) == args.trust_sha256, 'TRUST_ANCHOR_HASH')
        trust = strict_json(trust_raw)
        require(trust.get('schema') == 'odre-production-bootstrap-trust/v1', 'TRUST_SCHEMA')
        envelope_raw = read_regular(args.envelope, 16*1024*1024)
        signature_raw = read_regular(args.cms, 1024*1024)
        result['OUTER_CMS'] = verify_cms(envelope_raw, signature_raw, trust, args.trust.parent)
        envelope = strict_json(envelope_raw)
        raw = read_regular(args.bundle, MAX_ARCHIVE_BYTES)
        verified = verify_archive(raw, envelope, trust, args.expected_bundle_sha256)
        result['PREINSTALL'] = 'PASS'
        result['BUNDLE_SHA256'] = verified.archive_sha256
        result['VERIFIED_FILES'] = len(verified.files)
        if args.install_new is not None:
            if os.name == 'nt':
                require(sys.getwindowsversion().build == 20348 and platform.machine().upper() in ('AMD64', 'X86_64'), 'INSTALL_OS_CONTRACT')
            else:
                release = platform.freedesktop_os_release()
                require(release.get('ID') == 'ubuntu' and release.get('VERSION_ID') == '24.04'
                        and platform.machine() == 'x86_64', 'INSTALL_OS_CONTRACT')
            from atomic_install import install_new
            result['INSTALL'] = install_new(verified, args.install_new, trust, args.trust.parent)
            result['EXTRACTION'] = len(verified.files)
        print(json.dumps(result, separators=(',', ':')))
        return 0
    except Exception as exc:
        result['PREINSTALL'] = 'FAIL'
        result['ERROR'] = str(exc) if isinstance(exc, IntegrityError) else 'VERIFICATION_OR_INSTALL_FAILURE'
        # Failure after staging starts is an installation failure, not a claim
        # that no verified staging bytes were ever written. No product executes.
        if result.get('VERIFIED_FILES') is not None and args.install_new is not None:
            result['EXTRACTION'] = 'POST_VERIFICATION_INSTALL_ATTEMPT'
        print(json.dumps(result, separators=(',', ':')))
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
