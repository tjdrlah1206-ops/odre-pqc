"""Create a host-local Native authority config from a verified release config.

The signed release remains immutable. Only ca_file is rebound to the verified
CA in the actual installed platform root; all trust pins are preserved.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from pathlib import Path
from urllib.parse import urlsplit


HEX64 = re.compile(r"[0-9A-F]{64}\Z")
EXPECTED_KEYS = {
    "algorithm", "authority_url", "bootstrap_sha256", "ca_file", "ca_sha256",
    "key_id", "key_version", "public_key", "schema",
}


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest().upper()


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise RuntimeError("NATIVE_AUTHORITY_DUPLICATE_KEY")
        result[key] = value
    return result


def regular_bytes(path: Path, maximum: int) -> bytes:
    if path.is_symlink() or path.is_junction():
        raise RuntimeError("NATIVE_AUTHORITY_REPARSE_POINT")
    metadata = path.stat(follow_symlinks=False)
    if not path.is_file() or metadata.st_size > maximum:
        raise RuntimeError("NATIVE_AUTHORITY_FILE_INVALID")
    return path.read_bytes()


def generate(platform_root: Path, source_config: Path, expected_source_sha256: str,
             output: Path) -> dict:
    root = platform_root.resolve(strict=True)
    source = source_config.resolve(strict=True)
    try:
        source.relative_to(root)
    except ValueError as error:
        raise RuntimeError("NATIVE_AUTHORITY_SOURCE_OUTSIDE_RELEASE") from error
    source_raw = regular_bytes(source, 64 * 1024)
    if not HEX64.fullmatch(expected_source_sha256) or sha256(source_raw) != expected_source_sha256:
        raise RuntimeError("NATIVE_AUTHORITY_SOURCE_SHA256")
    value = json.loads(source_raw.decode("utf-8"), object_pairs_hook=strict_object)
    if type(value) is not dict or set(value) != EXPECTED_KEYS:
        raise RuntimeError("NATIVE_AUTHORITY_SCHEMA_FIELDS")
    if value["schema"] != "odre-native-authority-trust/v1":
        raise RuntimeError("NATIVE_AUTHORITY_SCHEMA")
    if value["algorithm"] != "ECDSA_P256_SHA256":
        raise RuntimeError("NATIVE_AUTHORITY_ALGORITHM")
    parsed = urlsplit(value["authority_url"])
    if parsed.scheme != "https" or not parsed.netloc or parsed.query or parsed.fragment:
        raise RuntimeError("NATIVE_AUTHORITY_URL")
    if (not HEX64.fullmatch(value["bootstrap_sha256"]) or
            not HEX64.fullmatch(value["ca_sha256"]) or
            type(value["key_version"]) is not int or value["key_version"] < 1 or
            type(value["key_id"]) is not str or not value["key_id"] or
            type(value["public_key"]) is not str or not value["public_key"]):
        raise RuntimeError("NATIVE_AUTHORITY_PIN_INVALID")
    ca_name = Path(value["ca_file"]).name
    if ca_name != "odreai-authority-root-ca.pem":
        raise RuntimeError("NATIVE_AUTHORITY_CA_NAME")
    ca = (root / "config" / ca_name).resolve(strict=True)
    try:
        ca.relative_to(root / "config")
    except ValueError as error:
        raise RuntimeError("NATIVE_AUTHORITY_CA_OUTSIDE_RELEASE") from error
    if sha256(regular_bytes(ca, 1024 * 1024)) != value["ca_sha256"]:
        raise RuntimeError("NATIVE_AUTHORITY_CA_SHA256")

    output = output.absolute()
    try:
        output.resolve(strict=False).relative_to(root)
    except ValueError:
        pass
    else:
        raise RuntimeError("NATIVE_AUTHORITY_OUTPUT_INSIDE_SIGNED_RELEASE")
    if output.exists() or output.is_symlink() or output.is_junction():
        raise RuntimeError("NATIVE_AUTHORITY_OUTPUT_EXISTS")
    if not output.parent.is_dir():
        raise RuntimeError("NATIVE_AUTHORITY_OUTPUT_PARENT")
    for ancestor in (output.parent, *output.parent.parents):
        if ancestor.is_symlink() or ancestor.is_junction():
            raise RuntimeError("NATIVE_AUTHORITY_OUTPUT_PARENT_REPARSE_POINT")

    local = dict(value)
    local["ca_file"] = str(ca)
    encoded = (json.dumps(local, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    with output.open("xb") as handle:
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())
    return {
        "status": "PASS",
        "output": str(output),
        "output_sha256": sha256(encoded),
        "source_sha256": expected_source_sha256,
        "ca_sha256": value["ca_sha256"],
        "trust_pins_changed": False,
        "signed_release_changed": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--platform-root", required=True, type=Path)
    parser.add_argument("--source-config", required=True, type=Path)
    parser.add_argument("--source-config-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    try:
        print(json.dumps(generate(args.platform_root, args.source_config,
                                  args.source_config_sha256, args.output),
                         sort_keys=True, separators=(",", ":")))
        return 0
    except Exception as error:
        print(json.dumps({"status": "FAIL", "error": str(error)},
                         sort_keys=True, separators=(",", ":")))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
