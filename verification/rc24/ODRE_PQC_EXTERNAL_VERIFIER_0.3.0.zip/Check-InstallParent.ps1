[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Directory,[Parameter(Mandatory=$true)][string]$OperatorSid)
$ErrorActionPreference='Stop'
$stage='ITEM'
try {
    Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Security\Microsoft.PowerShell.Security.psd1') -Force -ErrorAction Stop
    $item=Get-Item -LiteralPath $Directory -Force
    if (-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'TYPE' }
    $stage='ACL_READ'
    $acl=Get-Acl -LiteralPath $Directory
    $allowed=@('S-1-5-18','S-1-5-32-544',$OperatorSid)
    $stage='OWNER_CHECK'
    $owner=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
    if ($owner -notin $allowed -or -not $acl.AreAccessRulesProtected) { throw 'OWNER_OR_INHERITANCE' }
    $stage='RULE_CHECK'
    $danger=[Security.AccessControl.FileSystemRights]::Write -bor [Security.AccessControl.FileSystemRights]::Delete -bor [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor [Security.AccessControl.FileSystemRights]::ChangePermissions -bor [Security.AccessControl.FileSystemRights]::TakeOwnership
    foreach($rule in $acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
        if($rule.AccessControlType -eq 'Allow' -and $rule.IdentityReference.Value -notin $allowed -and ($rule.FileSystemRights -band $danger)) {throw 'UNAPPROVED_WRITE'}
    }
    Write-Output '{"protected_parent":true}'
    exit 0
} catch {
    @{protected_parent=$false;stage=$stage;error_type=$_.Exception.GetType().Name;error_id=$_.FullyQualifiedErrorId} | ConvertTo-Json -Compress
    exit 2
}
