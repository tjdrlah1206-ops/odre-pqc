"""Pinned CMS publisher verification in a trusted verifier environment.

Certificate/CRL checks are local. No OS trust installation, network fetching,
private key access, payload import or product archive extraction occurs.
"""
from __future__ import annotations

import datetime
import os
import subprocess
import tempfile
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.x509.oid import ObjectIdentifier

from bundle_gate import IntegrityError, require, sha, strict_json

def utc_field(value, name):
    modern = name + '_utc'
    if hasattr(value, modern):
        return getattr(value, modern)
    legacy = getattr(value, name)
    return legacy.replace(tzinfo=datetime.timezone.utc) if legacy is not None else None

def _tlv(raw, offset=0):
    require(offset + 2 <= len(raw), 'CMS_DER_TRUNCATED')
    tag, length = raw[offset], raw[offset + 1]
    cursor = offset + 2
    if length & 128:
        count = length & 127
        require(0 < count <= 4 and cursor + count <= len(raw), 'CMS_DER_LENGTH')
        require(raw[cursor] != 0, 'CMS_DER_NONCANONICAL')
        length = int.from_bytes(raw[cursor:cursor + count], 'big')
        require(length >= 128, 'CMS_DER_NONCANONICAL')
        cursor += count
    require(cursor + length <= len(raw), 'CMS_DER_TRUNCATED')
    return tag, raw[cursor:cursor + length], cursor + length

def _children(raw):
    result, cursor = [], 0
    while cursor < len(raw):
        tag, value, cursor = _tlv(raw, cursor)
        result.append((tag, value))
    return result

def require_detached_single_signer(raw):
    tag, body, end = _tlv(raw)
    require(tag == 0x30 and end == len(raw), 'CMS_CONTENT_INFO')
    info = _children(body)
    require(len(info) == 2 and info[0] == (6, bytes.fromhex('2a864886f70d010702')) and info[1][0] == 0xA0, 'CMS_SIGNED_DATA')
    tag, body, end = _tlv(info[1][1])
    require(tag == 0x30 and end == len(info[1][1]), 'CMS_SIGNED_DATA')
    signed = _children(body)
    require(len(signed) >= 4 and signed[2][0] == 0x30 and signed[-1][0] == 0x31, 'CMS_SIGNED_DATA')
    require(_children(signed[2][1]) == [(6, bytes.fromhex('2a864886f70d010701'))], 'CMS_NOT_DETACHED')
    require(len(_children(signed[-1][1])) == 1, 'CMS_SIGNER_COUNT')
    digest_set = _children(signed[1][1])
    require(len(digest_set) == 1 and digest_set[0][0] == 0x30, 'CMS_DIGEST_POLICY')
    digest = _children(digest_set[0][1])
    require(digest and digest[0] == (6, bytes.fromhex('608648016503040201')), 'CMS_DIGEST_POLICY')

def read_regular(path: Path, limit: int) -> bytes:
    path = path.absolute()
    for ancestor in (path, *path.parents):
        require(not ancestor.is_symlink() and not ancestor.is_junction(), 'INPUT_LINK_REJECTED')
    before = path.stat(follow_symlinks=False)
    require(path.is_file() and before.st_size <= limit, 'INPUT_TYPE_OR_SIZE')
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        require((opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino), 'INPUT_IDENTITY_RACE')
        # Bound allocation by the opened file size, retaining the global cap.
        data = stream.read(min(limit, opened.st_size) + 1)
        after = os.fstat(stream.fileno())
    require(len(data) == opened.st_size and len(data) <= limit and (opened.st_size, opened.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'INPUT_CHANGED')
    return data

def verify_cms(content: bytes, signature: bytes, trust: dict, trusted_base: Path):
    require_detached_single_signer(signature)
    public = trust['publisher']
    require(set(public) == {'root_file', 'root_sha256', 'leaf_file', 'leaf_sha256', 'crl_file', 'eku'}, 'PUBLISHER_FIELDS')
    def material(field, limit=1024*1024):
        relative = Path(public[field])
        require(not relative.is_absolute() and '..' not in relative.parts, 'TRUST_MATERIAL_PATH')
        return read_regular(trusted_base / relative, limit)
    def certificate(raw):
        return x509.load_pem_x509_certificate(raw) if raw.startswith(b'-----BEGIN CERTIFICATE-----') else x509.load_der_x509_certificate(raw)
    root, leaf = certificate(material('root_file')), certificate(material('leaf_file'))
    require(sha(root.public_bytes(serialization.Encoding.DER)) == public['root_sha256'], 'ROOT_PIN')
    require(sha(leaf.public_bytes(serialization.Encoding.DER)) == public['leaf_sha256'], 'LEAF_PIN')
    now = datetime.datetime.now(datetime.timezone.utc)
    for cert in (root, leaf):
        require(utc_field(cert, 'not_valid_before') <= now <= utc_field(cert, 'not_valid_after'), 'CERTIFICATE_VALIDITY')
    try:
        root.verify_directly_issued_by(root)
        leaf.verify_directly_issued_by(root)
        require(root.extensions.get_extension_for_class(x509.BasicConstraints).value.ca, 'ROOT_NOT_CA')
        require(not leaf.extensions.get_extension_for_class(x509.BasicConstraints).value.ca, 'LEAF_IS_CA')
        require(leaf.extensions.get_extension_for_class(x509.KeyUsage).value.digital_signature, 'LEAF_KEY_USAGE')
        require(ObjectIdentifier(public['eku']) in leaf.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value, 'LEAF_EKU')
        require(public['eku'] == '1.3.6.1.4.1.311.10.3.12', 'MANIFEST_ROLE_EKU')
    except IntegrityError:
        raise
    except Exception as exc:
        raise IntegrityError('CERTIFICATE_CHAIN_OR_ROLE') from exc
    raw_crl = material('crl_file')
    crl = x509.load_pem_x509_crl(raw_crl) if raw_crl.startswith(b'-----BEGIN X509 CRL-----') else x509.load_der_x509_crl(raw_crl)
    require(crl.issuer == root.subject and crl.is_signature_valid(root.public_key()), 'CRL_SIGNATURE')
    require(utc_field(crl, 'next_update') is not None and utc_field(crl, 'last_update') <= now <= utc_field(crl, 'next_update'), 'CRL_VALIDITY')
    require(crl.get_revoked_certificate_by_serial_number(leaf.serial_number) is None, 'SIGNER_REVOKED')
    require(crl.signature_hash_algorithm.name in ('sha256', 'sha384', 'sha512'), 'CRL_DIGEST')
    backend = trust['cms_backends'].get('windows' if os.name == 'nt' else 'linux')
    require(isinstance(backend, dict), 'CMS_BACKEND_MISSING')
    executable = Path(backend['executable'])
    require(executable.is_absolute() and sha(read_regular(executable, 64*1024*1024)) == backend['executable_sha256'], 'CMS_TOOL_PIN')
    # Only public validation metadata is written here. No ZIP member or key is
    # materialized. This temporary directory belongs to the trusted verifier.
    with tempfile.TemporaryDirectory(prefix='odre-cms-public-') as temporary:
        temp = Path(temporary)
        content_path, signature_path = temp/'content.json', temp/'signature.p7s'
        content_path.write_bytes(content)
        signature_path.write_bytes(signature)
        if os.name == 'nt':
            require(not Path(backend['helper']).is_absolute() and '..' not in Path(backend['helper']).parts, 'CMS_HELPER_PATH')
            helper = trusted_base / backend['helper']
            require(sha(read_regular(helper, 1024*1024)) == backend['helper_sha256'], 'CMS_HELPER_PIN')
            command = [str(executable), '-NoLogo', '-NoProfile', '-NonInteractive', '-File', str(helper),
                       '-ContentPath', str(content_path), '-SignaturePath', str(signature_path),
                       '-ExpectedSignerSha256', public['leaf_sha256']]
        else:
            leaf_path = temp/'pinned-leaf.pem'
            leaf_path.write_bytes(leaf.public_bytes(serialization.Encoding.PEM))
            # -noverify applies only to OpenSSL's implicit trust-store chain.
            # Explicit pins, chain, EKU and signed CRL were all required above.
            command = [str(executable), 'cms', '-verify', '-binary', '-inform', 'DER',
                       '-in', str(signature_path), '-content', str(content_path),
                       '-nointern', '-certfile', str(leaf_path), '-noverify', '-out', os.devnull]
        completed = subprocess.run(command, stdin=subprocess.DEVNULL, capture_output=True,
                                   timeout=30, check=False, cwd=temporary)
        require(completed.returncode == 0, 'CMS_CRYPTOGRAPHIC_SIGNATURE')
        if os.name == 'nt':
            receipt = strict_json(completed.stdout.strip())
            require(receipt.get('signature_valid') is True and receipt.get('signer_sha256') == public['leaf_sha256'], 'CMS_RECEIPT')
    return {'publisher_sha256': public['leaf_sha256'], 'chain_pin_eku_revocation': 'PASS', 'signature': 'PASS'}
