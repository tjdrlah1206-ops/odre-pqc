# ODRE PQC 0.3.0 - external pre-install verification

ODRE customer installation uses device registration, with no customer account or login. The operating-system operator SID below is a Windows file-permission identity, not an ODRE customer identity.

Obtain this verifier kit, its SHA-256, the policy SHA-256 and the product ZIP SHA-256 through an independently trusted release channel. Never bootstrap trust by executing code extracted from an unverified product ZIP. Use an independently trusted Python 3.12 installation with cryptography; the actual tests used cryptography 50.0.0 on Windows and 41.0.7 on Ubuntu. These are observed versions, not a claim that every other version is supported.

Prepare a protected installation parent first. The destination itself must not exist. Windows requires protected ACL inheritance and an owner/write policy limited to SYSTEM, Administrators and the approved operating-system operator. Ubuntu requires root-owned parent directories with no group/world write permission and provisioning as root. Run the product afterwards under its approved operating-system execution identity, preserving the device state directory.

Run the following from the externally verified kit directory. Replace every placeholder with an independently approved local value. Approve the PowerShell/OpenSSL executable before supplying its hash; measuring arbitrary software does not approve it. The configuration output must be a new filename beside the policy and public certificate files. Record the returned trust_sha256 and use that exact value for pre-install verification.

## Windows Server 2022 - PowerShell

```powershell
$python = '<TRUSTED_PYTHON_3_12_ABSOLUTE_PATH>'
& $python -B .\prepare_customer_verifier_config.py `
  --policy .\verifier-policy.json `
  --policy-sha256 '<INDEPENDENT_POLICY_SHA256>' `
  --platform windows `
  --cms-tool '<APPROVED_POWERSHELL_EXE_ABSOLUTE_PATH>' `
  --cms-tool-sha256 '<APPROVED_POWERSHELL_SHA256>' `
  --operator-sid '<APPROVED_WINDOWS_OPERATOR_SID>' `
  --output .\local-trust.json
if ($LASTEXITCODE -ne 0) { throw 'VERIFIER_CONFIGURATION_FAILED' }

& $python -B .\trusted_preinstall.py `
  --bundle '<BUNDLE_ZIP_ABSOLUTE_PATH>' `
  --envelope '<BUNDLE_ENVELOPE_ABSOLUTE_PATH>' `
  --cms '<DETACHED_CMS_ABSOLUTE_PATH>' `
  --trust .\local-trust.json `
  --trust-sha256 '<RETURNED_LOCAL_TRUST_SHA256>' `
  --expected-bundle-sha256 '<INDEPENDENT_BUNDLE_SHA256>' `
  --install-new '<NEW_RELEASE_DIRECTORY_ABSOLUTE_PATH>'
if ($LASTEXITCODE -ne 0) { throw 'VERIFIED_INSTALL_FAILED' }
```

## Ubuntu 24.04 - Bash

Use the independently verified kit and approved Python environment in a root-owned, non-user-writable directory. Run these provisioning commands in the approved root provisioning context; do not run an untrusted user-writable Python environment as root.

```bash
python='<TRUSTED_PYTHON_3_12_ABSOLUTE_PATH>'
"$python" -B ./prepare_customer_verifier_config.py \
  --policy ./verifier-policy.json \
  --policy-sha256 '<INDEPENDENT_POLICY_SHA256>' \
  --platform ubuntu \
  --cms-tool '<APPROVED_OPENSSL_ABSOLUTE_PATH>' \
  --cms-tool-sha256 '<APPROVED_OPENSSL_SHA256>' \
  --output ./local-trust.json || exit 1

"$python" -B ./trusted_preinstall.py \
  --bundle '<BUNDLE_ZIP_ABSOLUTE_PATH>' \
  --envelope '<BUNDLE_ENVELOPE_ABSOLUTE_PATH>' \
  --cms '<DETACHED_CMS_ABSOLUTE_PATH>' \
  --trust ./local-trust.json \
  --trust-sha256 '<RETURNED_LOCAL_TRUST_SHA256>' \
  --expected-bundle-sha256 '<INDEPENDENT_BUNDLE_SHA256>' \
  --install-new '<NEW_RELEASE_DIRECTORY_ABSOLUTE_PATH>' || exit 1
```

Omit --install-new for verification only. A successful verifier installation neither runs product code nor starts a Trial or generates device identity. Continue with the platform Native installation guide. Existing installations require the authenticated upgrade contract; never delete their state or use --install-new over an existing directory. The local trust file is specific to this host and is not a redistributable customer template.

## Interrupted-install staging diagnosis

Each normal failure removes only the random staging directory created by that invocation. A forced process termination can prevent `finally` cleanup. Before retrying, inventory the exact protected installation parent:

```powershell
& $python -B .\staging_maintenance.py --parent '<INSTALL_PARENT_ABSOLUTE_PATH>'
```

The command is read-only. It recognizes only an immediate child whose full name is `.odre-verified-` followed by 32 lowercase hexadecimal characters, refuses traversal through reparse points, and reports file counts and bytes without reading file contents. It never deletes a directory because legacy staging contains no durable ownership lease proving that another installer is not using it. A candidate reported as `LEGACY_OWNERSHIP_UNPROVEN` may be removed only by an administrator after separately confirming that no installer process is active and supplying that one exact path to a literal-path removal command. Do not use wildcards, recursive name searches, or remove an existing release directory. A retry can proceed without removing such residue; the installer uses a fresh random directory and never replaces an existing release.

## Native authority config for the actual install location

The signed platform release contains an authority config for the documented default path. For a default or custom installation, create a separate host-local config after verified installation. Supply the independently recorded SHA-256 of the signed source config. The generator verifies the signed config and installed CA, preserves the authority URL, key ID, public key, algorithm, CA hash and bootstrap hash, changes only `ca_file`, refuses to write inside the signed release, and prints the exact SHA-256 of the new local file.

```powershell
$platformRoot = '<VERIFIED_WINDOWS_PLATFORM_ROOT>'
& $python -B .\prepare_native_authority_config.py `
  --platform-root $platformRoot `
  --source-config "$platformRoot\config\native-authority-trust.json" `
  --source-config-sha256 '<SIGNED_SOURCE_CONFIG_SHA256>' `
  --output '<PROTECTED_LOCAL_STATE_DIRECTORY>\native-authority-trust.local.json'
if ($LASTEXITCODE -ne 0) { throw 'NATIVE_AUTHORITY_CONFIGURATION_FAILED' }
```

Pass the returned `output_sha256` together with that exact local config path to the existing Native command. Do not overwrite `config\native-authority-trust.json` in the verified release. Protect the local state directory with the same approved operating-system identity and ACL used for Native state. The Ubuntu command uses the same arguments and writes outside the signed release into its approved root-owned state directory.

The kit contains only public certificates, signed CRL, policy and verification code. It never supplies a License Key, content key, private signing key or customer credential. Release readiness is determined by the separately published approval report bound to the exact archive hash.
