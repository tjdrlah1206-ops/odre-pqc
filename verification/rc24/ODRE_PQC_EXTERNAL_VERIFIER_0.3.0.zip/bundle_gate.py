"""Product-independent, read-only gates for an authenticated customer archive.

Runs in a separately trusted verifier environment, never the bundled interpreter.
The caller must verify the outer CMS before invoking verify_archive. No import,
extraction, package manager or product process is used by this module.
"""
from __future__ import annotations

import hashlib
import base64
import io
import json
import re
import stat
import unicodedata
import zipfile
from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

CORE_SHA256 = 'A8AFA10EE0AFACEF1C0FAF55FF07B96C722920E5AEE8692F6F026E804F028697'
CORE_BYTES = 4022159
INNER_FINGERPRINT = 'D9026275A976F13D98777539AB635DD3EF48012E9D1BE6F1691205E1BCB7A7A9'
INNER_KEY_ID = 'D9026275A976F13D98777539'
INNER_FIELDS = frozenset(('artifact_inner_sha256', 'artifact_version', 'cipher', 'nonce',
    'payload_bytes', 'payload_file', 'payload_id', 'payload_sha256', 'protocol_version',
    'schema', 'signing_key_id'))
MAX_ARCHIVE_BYTES = 1024 * 1024 * 1024
MAX_UNCOMPRESSED_BYTES = 2 * 1024 * 1024 * 1024
MAX_MEMBERS = 16384
HEX = re.compile(r'[0-9A-F]{64}\Z')

class IntegrityError(Exception):
    """Stable, non-sensitive error code; never embeds bytes or user paths."""

def require(condition, code):
    if not condition:
        raise IntegrityError(code)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()

def _decode_base64url_unpadded(value: str) -> bytes:
    require(isinstance(value, str) and value and '=' not in value,
            'BASE64URL_UNPADDED')
    padding = '=' * ((4 - len(value) % 4) % 4)
    try:
        decoded = base64.b64decode(value + padding, altchars=b'-_', validate=True)
    except Exception as exc:
        raise IntegrityError('BASE64URL_INVALID') from exc
    require(base64.urlsafe_b64encode(decoded).rstrip(b'=').decode() == value,
            'BASE64URL_NONCANONICAL')
    return decoded

def strict_json(raw: bytes):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'JSON_DUPLICATE_KEY')
            result[key] = value
        return result
    try:
        return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(IntegrityError('JSON_NONFINITE')))
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise IntegrityError('JSON_INVALID') from exc

def safe_name(name: str) -> str:
    require(isinstance(name, str) and 0 < len(name) <= 240, 'PATH_INVALID')
    require(name == unicodedata.normalize('NFC', name), 'PATH_NONCANONICAL')
    require(not any(ord(c) < 32 or ord(c) == 127 for c in name), 'PATH_CONTROL')
    require(not any(c in name for c in '\\:*?"<>|'), 'PATH_PLATFORM_UNSAFE')
    parts = name.split('/')
    for part in parts:
        require(part not in ('', '.', '..') and not part.endswith((' ', '.')), 'PATH_UNSAFE')
        require(not re.fullmatch(r'(?i)(con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])(?:\..*)?', part), 'PATH_RESERVED')
    return name

def _require_shipping_member(name: str) -> None:
    """Reject build residue except cache files bound by a platform runtime manifest."""
    parts = tuple(part.casefold() for part in name.split('/'))
    runtime_member = name.startswith((
        'WINDOWS_SERVER_2022/runtime/',
        'UBUNTU_24_04/runtime/',
    ))
    blocked_parts = {'test', 'tests', 'fixture', 'fixtures', 'evidence',
                     '.git', '.venv', 'node_modules'}
    require(not any(part in blocked_parts for part in parts), 'NONSHIPPING_MEMBER')
    has_cache = '__pycache__' in parts
    cache_bytecode = name.lower().endswith(('.pyc', '.pyo'))
    require(not has_cache or (runtime_member and cache_bytecode), 'NONSHIPPING_MEMBER')
    require(not cache_bytecode or (runtime_member and has_cache), 'NONSHIPPING_MEMBER')
    require(not name.lower().endswith(('.log', '.dpapi', '.pem.key', '.pfx', '.p12')),
            'NONSHIPPING_MEMBER')

def record(raw: bytes, item: dict):
    require(isinstance(item, dict) and set(item) == {'bytes', 'sha256', 'mode'}, 'INVENTORY_FIELDS')
    require(type(item['bytes']) is int and item['bytes'] >= 0, 'INVENTORY_SIZE')
    require(isinstance(item['sha256'], str) and HEX.fullmatch(item['sha256']), 'INVENTORY_HASH')
    require(item['mode'] in (0o644, 0o755), 'INVENTORY_MODE')
    require(len(raw) == item['bytes'] and sha(raw) == item['sha256'], 'FILE_INTEGRITY')

@dataclass(frozen=True)
class VerifiedArchive:
    """Immutable snapshots, available only after all content gates return."""
    archive_sha256: str
    product: str
    version: str
    files: Mapping[str, bytes]
    modes: Mapping[str, int]

def _ed_verify(public: bytes, signature: bytes, raw: bytes, fingerprint: str):
    require(len(public) == 32 and sha(public) == fingerprint, 'ED25519_PUBLIC_PIN')
    require(len(signature) == 64, 'ED25519_SIGNATURE_SIZE')
    try:
        Ed25519PublicKey.from_public_bytes(public).verify(signature, raw)
    except Exception as exc:
        raise IntegrityError('ED25519_SIGNATURE_INVALID') from exc

def _verify_runtime_binding(public: bytes, signature: bytes, binding_raw: bytes,
                            manifest_raw: bytes, fingerprint: str, key_id: str):
    """Verify the pure-Ed25519 binding for a runtime manifest larger than KMS limits."""
    _ed_verify(public, signature, binding_raw, fingerprint)
    binding = strict_json(binding_raw)
    require(isinstance(binding, dict) and set(binding) == {
        'manifest_bytes', 'manifest_sha256', 'schema', 'signing_key_id'
    }, 'RUNTIME_BINDING_FIELDS')
    require(binding.get('schema') == 'odre-commercial-python-runtime-binding/v1',
            'RUNTIME_BINDING_SCHEMA')
    require(binding.get('signing_key_id') == key_id,
            'RUNTIME_BINDING_KEY')
    require(type(binding.get('manifest_bytes')) is int and
            binding['manifest_bytes'] == len(manifest_raw) and
            binding.get('manifest_sha256') == sha(manifest_raw),
            'RUNTIME_BINDING_MANIFEST')

def verify_platform(files: Mapping[str, bytes], platform: dict, trust: dict):
    expected_fields = {'os', 'architecture', 'inner_manifest', 'inner_signature', 'inner_public',
        'payload', 'native', 'runtime_manifest', 'runtime_binding', 'runtime_signature', 'runtime_public',
        'runtime_root', 'startup_script', 'python_version', 'runtime_key_id'}
    require(isinstance(platform, dict) and set(platform) == expected_fields, 'PLATFORM_FIELDS')
    require(platform['os'] in ('WINDOWS_SERVER_2022', 'UBUNTU_24_04') and
            platform['architecture'] == 'AMD64', 'PLATFORM_UNSUPPORTED')
    def get(field):
        name = safe_name(platform[field])
        require(name in files, 'PLATFORM_MEMBER_MISSING')
        require(name.startswith(platform['os'] + '/'), 'PLATFORM_PATH_BINDING')
        return files[name]
    manifest_raw = get('inner_manifest')
    _ed_verify(get('inner_public'), get('inner_signature'), manifest_raw, INNER_FINGERPRINT)
    inner = strict_json(manifest_raw)
    require(isinstance(inner, dict) and set(inner) == INNER_FIELDS, 'INNER_MANIFEST_FIELDS')
    expected = {'artifact_inner_sha256': CORE_SHA256, 'artifact_version': '0.2.9',
        'cipher': 'AES-256-GCM', 'payload_file': 'odre_pqc-0.2.9.whl.enc',
        'protocol_version': 'odre-commercial-bootstrap/v1',
        'schema': 'odre-commercial-encrypted-artifact/v1', 'signing_key_id': INNER_KEY_ID}
    require(all(inner.get(k) == v for k, v in expected.items()), 'INNER_MANIFEST_IDENTITY')
    require(platform['payload'].rsplit('/', 1)[-1] == inner['payload_file'], 'PAYLOAD_NAME')
    payload = get('payload')
    require(type(inner['payload_bytes']) is int and len(payload) == inner['payload_bytes']
            and sha(payload) == inner['payload_sha256'], 'ENCRYPTED_PAYLOAD_INTEGRITY')
    require(len(payload) == CORE_BYTES + 16, 'ENCRYPTED_PAYLOAD_SIZE_CONTRACT')
    try:
        nonce = _decode_base64url_unpadded(inner['nonce'])
    except IntegrityError as exc:
        raise IntegrityError('INNER_NONCE') from exc
    require(len(nonce) == 12, 'INNER_NONCE')
    require(isinstance(inner['payload_id'], str) and 1 <= len(inner['payload_id']) <= 128, 'INNER_PAYLOAD_ID')
    native = get('native')
    if platform['os'] == 'WINDOWS_SERVER_2022':
        require(native[:2] == b'MZ' and len(native) > 64, 'NATIVE_FORMAT')
        pe = int.from_bytes(native[60:64], 'little')
        require(native[pe:pe+4] == b'PE\x00\x00' and native[pe+4:pe+6] == b'\x64\x86', 'NATIVE_ARCH')
    else:
        require(native[:6] == b'\x7fELF\x02\x01' and native[18:20] == b'\x3e\x00', 'NATIVE_ARCH')
    runtime_raw = get('runtime_manifest')
    runtime_pin = trust['runtime_signers'].get(platform['os'])
    require(isinstance(runtime_pin, dict) and set(runtime_pin) == {'key_id', 'public_sha256'}, 'RUNTIME_TRUST_MISSING')
    require(platform['runtime_key_id'] == runtime_pin['key_id'], 'RUNTIME_KEY_BINDING')
    require(not re.search(r'(?i)test|poc|dev|legacy|isolated', platform['runtime_key_id']), 'RUNTIME_NONPRODUCTION_SIGNER')
    _verify_runtime_binding(get('runtime_public'), get('runtime_signature'),
                            get('runtime_binding'), runtime_raw,
                            runtime_pin['public_sha256'], platform['runtime_key_id'])
    runtime = strict_json(runtime_raw)
    require(isinstance(runtime, dict) and runtime.get('schema') == 'odre-commercial-python-runtime/v1', 'RUNTIME_SCHEMA')
    require(runtime.get('architecture') == 'AMD64' and runtime.get('artifact_inner_sha256') == CORE_SHA256
            and runtime.get('bootstrap_protocol') == 'odre-commercial-bootstrap/v1'
            and runtime.get('python_version') == platform['python_version']
            and runtime.get('signing_key_id') == platform['runtime_key_id'], 'RUNTIME_IDENTITY')
    root = safe_name(platform['runtime_root']) + '/'
    require(root.startswith(platform['os'] + '/'), 'RUNTIME_ROOT')
    seen = set()
    require(isinstance(runtime.get('runtime_files'), list), 'RUNTIME_FILES')
    for item in runtime['runtime_files']:
        require(isinstance(item, dict) and set(item) == {'path', 'bytes', 'sha256'}, 'RUNTIME_ENTRY')
        path = root + safe_name(item['path'])
        require(path not in seen and path in files, 'RUNTIME_MEMBER')
        seen.add(path)
        require(len(files[path]) == item['bytes'] and sha(files[path]) == item['sha256'], 'RUNTIME_FILE_HASH')
    require(type(runtime.get('runtime_file_count')) is int and len(seen) == runtime['runtime_file_count'], 'RUNTIME_COUNT')
    require(seen == {name for name in files if name.startswith(root)}, 'RUNTIME_COVERAGE')
    startup = get('startup_script')
    require(runtime.get('startup_script') == {'bytes': len(startup), 'sha256': sha(startup)}, 'STARTUP_HASH')

def verify_archive(raw: bytes, envelope: dict, trust: dict, expected_sha256: str) -> VerifiedArchive:
    """Call only with an envelope whose detached CMS has already been verified."""
    require(isinstance(envelope, dict) and set(envelope) == {'schema', 'product', 'version',
        'archive', 'files', 'platforms', 'core', 'gateway', 'commercial', 'release_generation'}, 'ENVELOPE_FIELDS')
    require(envelope['schema'] == 'odre-production-bundle-envelope/v1', 'ENVELOPE_SCHEMA')
    require(envelope['product'] == trust['product'] and envelope['version'] == trust['version'], 'PRODUCT_BINDING')
    require(type(envelope['release_generation']) is int and envelope['release_generation'] >= trust['minimum_release_generation'], 'STALE_RELEASE')
    require(envelope['core'] == {'package': 'odre-pqc', 'version': '0.2.9', 'bytes': CORE_BYTES, 'sha256': CORE_SHA256}, 'CORE_BINDING')
    require(isinstance(expected_sha256, str) and HEX.fullmatch(expected_sha256), 'EXPECTED_RELEASE_HASH')
    archive = envelope['archive']
    require(isinstance(archive, dict) and set(archive) == {'bytes', 'sha256'}, 'ARCHIVE_FIELDS')
    require(len(raw) <= MAX_ARCHIVE_BYTES and len(raw) == archive['bytes'] and sha(raw) == expected_sha256 == archive['sha256'], 'ARCHIVE_HASH')
    expected = envelope['files']
    require(isinstance(expected, dict) and 0 < len(expected) <= MAX_MEMBERS, 'ALLOWLIST_SIZE')
    folded = set()
    for name in expected:
        safe_name(name)
        require(name.casefold() not in folded, 'ALLOWLIST_CASE_COLLISION')
        folded.add(name.casefold())
        _require_shipping_member(name)
        require(not name.rsplit('/', 1)[-1].startswith('odre_pqc-0.2.9') or name.endswith('.whl.enc'), 'PLAINTEXT_CORE_FORBIDDEN')
    for name in folded:
        parts = name.split('/')
        require(not any('/'.join(parts[:i]) in folded for i in range(1, len(parts))), 'ALLOWLIST_FILE_DIRECTORY_COLLISION')
    files = {}
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as zf:
            infos = zf.infolist()
            require(len(infos) == len(expected), 'ZIP_ALLOWLIST_COUNT')
            require(sum(i.file_size for i in infos) <= MAX_UNCOMPRESSED_BYTES, 'ZIP_SIZE_LIMIT')
            for info in infos:
                require(info.orig_filename == info.filename, 'ZIP_TRUNCATED_MEMBER_NAME')
                name = safe_name(info.filename)
                require(name in expected and name not in files, 'ZIP_DUPLICATE_OR_UNEXPECTED')
                require(not info.is_dir() and not (info.flag_bits & 1), 'ZIP_MEMBER_TYPE')
                kind = stat.S_IFMT(info.external_attr >> 16)
                require(kind in (0, stat.S_IFREG), 'ZIP_SPECIAL_FILE')
                require(info.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED), 'ZIP_COMPRESSION')
                require(info.file_size == expected[name]['bytes'], 'ZIP_DECLARED_SIZE')
                content = zf.read(info)  # CRC checked; no filesystem extraction.
                record(content, expected[name])
                files[name] = content
    except (zipfile.BadZipFile, RuntimeError, KeyError, NotImplementedError, EOFError) as exc:
        raise IntegrityError('ZIP_INVALID') from exc
    require(set(files) == set(expected), 'ZIP_COVERAGE')
    require(isinstance(envelope['platforms'], list) and len(envelope['platforms']) == 2, 'PLATFORM_COUNT')
    require({p.get('os') for p in envelope['platforms']} == {'WINDOWS_SERVER_2022', 'UBUNTU_24_04'}, 'PLATFORM_SET')
    for platform in envelope['platforms']:
        verify_platform(files, platform, trust)
    for component in ('gateway', 'commercial'):
        identity = envelope[component]
        require(isinstance(identity, dict) and set(identity) == {'manifest', 'sha256', 'package', 'version'}, 'COMPONENT_IDENTITY')
        name = safe_name(identity['manifest'])
        require(name in files and sha(files[name]) == identity['sha256'], 'COMPONENT_MANIFEST_HASH')
        require(isinstance(identity['package'], str) and bool(identity['package']) and isinstance(identity['version'], str) and bool(identity['version']), 'COMPONENT_VERSION')
    return VerifiedArchive(sha(raw), envelope['product'], envelope['version'],
                           MappingProxyType(files), MappingProxyType({n: r['mode'] for n, r in expected.items()}))
