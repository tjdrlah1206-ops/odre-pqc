"""Install an already verified immutable snapshot into a new release directory.

Never invokes package managers, starts product code, or touches identity state.
Updating an existing target is deliberately rejected; authenticated upgrade
activation is a separate contract, not a delete-and-reinstall shortcut.
"""
from __future__ import annotations
import ctypes
import os
import shutil
import stat
import subprocess
import uuid
from pathlib import Path

from bundle_gate import VerifiedArchive, require, IntegrityError, sha
from cms_gate import read_regular, strict_json
from staging_maintenance import inspect_staging

def install_new(verified: VerifiedArchive, destination: Path, trust: dict, trusted_base: Path):
    require(type(verified) is VerifiedArchive, 'VERIFIED_SNAPSHOT_REQUIRED')
    destination = destination.absolute()
    require(not destination.exists() and not destination.is_symlink() and not destination.is_junction(), 'INSTALL_TARGET_EXISTS')
    parent = destination.parent
    require(parent.is_dir(), 'INSTALL_PARENT_MISSING')
    for ancestor in (parent, *parent.parents):
        require(not ancestor.is_symlink() and not ancestor.is_junction(), 'INSTALL_PARENT_LINK')
    handles = []
    parent_fd = None
    staging = None
    committed = False
    residue = inspect_staging(parent)
    try:
        if os.name == 'nt':
            policy = trust['install']['windows']
            backend = trust['cms_backends']['windows']
            executable = Path(backend['executable'])
            helper = trusted_base / policy['parent_acl_helper']
            require(sha(read_regular(executable, 64*1024*1024)) == backend['executable_sha256'], 'INSTALL_TOOL_PIN')
            require(sha(read_regular(helper, 1024*1024)) == policy['parent_acl_helper_sha256'], 'INSTALL_HELPER_PIN')
            # Hold directory handles without FILE_SHARE_DELETE through commit.
            kernel = ctypes.WinDLL('kernel32', use_last_error=True)
            kernel.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p]
            kernel.CreateFileW.restype = ctypes.c_void_p
            kernel.CloseHandle.argtypes = [ctypes.c_void_p]
            for ancestor in (parent, *parent.parents):
                handle = kernel.CreateFileW(str(ancestor), 0x80000000, 3, None, 3, 0x02200000, None)
                require(handle not in (None, ctypes.c_void_p(-1).value), 'INSTALL_PARENT_LOCK')
                handles.append(handle)
            proc = subprocess.run([str(executable), '-NoLogo', '-NoProfile', '-NonInteractive', '-File', str(helper),
                 '-Directory', str(parent), '-OperatorSid', policy['operator_sid']], capture_output=True,
                 stdin=subprocess.DEVNULL, check=False, timeout=30)
            require(proc.returncode == 0 and strict_json(proc.stdout.strip()).get('protected_parent') is True, 'INSTALL_PARENT_ACL')
        else:
            require(os.geteuid() == 0, 'ROOT_PROVISIONING_REQUIRED')
            for ancestor in (parent, *parent.parents):
                metadata = ancestor.stat(follow_symlinks=False)
                require(metadata.st_uid == 0 and not metadata.st_mode & 0o022, 'INSTALL_PARENT_PERMISSIONS')
            parent_fd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            require(os.fstat(parent_fd).st_ino == parent.stat(follow_symlinks=False).st_ino, 'INSTALL_PARENT_RACE')
        staging = parent / ('.odre-verified-' + uuid.uuid4().hex)
        staging.mkdir(mode=0o700)
        for name, raw in verified.files.items():
            target = staging / name
            target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with target.open('xb') as handle:
                handle.write(raw)
                handle.flush()
                os.fsync(handle.fileno())
            if os.name != 'nt':
                target.chmod(verified.modes[name])
        # Verify installed bytes before publishing the new release directory.
        for name, raw in verified.files.items():
            require(sha((staging/name).read_bytes()) == sha(raw), 'STAGING_READBACK')
        if os.name != 'nt':
            for directory in sorted((p for p in staging.rglob('*') if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
                directory.chmod(0o755)
                fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
                try: os.fsync(fd)
                finally: os.close(fd)
            staging.chmod(0o755)
            fd = os.open(staging, os.O_RDONLY | os.O_DIRECTORY)
            try: os.fsync(fd)
            finally: os.close(fd)
            libc = ctypes.CDLL(None, use_errno=True)
            rename = getattr(libc, 'renameat2', None)
            require(rename is not None, 'ATOMIC_NOREPLACE_UNAVAILABLE')
            rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
            rename.restype = ctypes.c_int
            require(rename(parent_fd, os.fsencode(staging.name), parent_fd, os.fsencode(destination.name), 1) == 0, 'ATOMIC_INSTALL_COMMIT')
            os.fsync(parent_fd)
        else:
            # Windows rename rejects an existing destination. WRITE_THROUGH
            # requests durable metadata completion without replacement flags.
            kernel.MoveFileExW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint32]
            kernel.MoveFileExW.restype = ctypes.c_int
            require(kernel.MoveFileExW(str(staging), str(destination), 8) != 0, 'ATOMIC_INSTALL_COMMIT')
        committed = True
        return {'installation': 'NEW_IMMUTABLE_RELEASE_INSTALLED', 'files': len(verified.files),
                'identity_state_touched': False, 'pip_invoked': False, 'runtime_loaded': False,
                'staging_residue_detected': len(residue),
                'staging_residue_automatic_cleanup': False}
    finally:
        # Only the fresh, random staging directory created in this invocation
        # is eligible for cleanup. No candidate or existing release is deleted.
        if staging is not None and not committed and staging.exists():
            require(staging.parent == parent and staging.name.startswith('.odre-verified-')
                    and not staging.is_symlink() and not staging.is_junction(), 'STAGING_CLEANUP_PATH')
            shutil.rmtree(staging)
        if parent_fd is not None:
            os.close(parent_fd)
        if os.name == 'nt':
            for handle in reversed(handles): kernel.CloseHandle(handle)
