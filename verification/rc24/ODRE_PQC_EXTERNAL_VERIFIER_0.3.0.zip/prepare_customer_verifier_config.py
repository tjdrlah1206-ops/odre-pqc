"""Prepare local verifier pins from an independently trusted public policy.

This tool is part of the separately trusted verifier kit, not an installer that
bootstraps its own trust from an unverified product archive. It does not run the
CMS tool, install anything, discover credentials, or contact a network service.
The administrator supplies the locally approved CMS tool hash explicitly.
"""
import argparse,json,os,re,sys
from pathlib import Path

if sys.version_info[:2] != (3,12):
 print('PYTHON_3_12_REQUIRED',file=sys.stderr)
 raise SystemExit(2)
from bundle_gate import require,sha,strict_json,IntegrityError
from cms_gate import read_regular

ROOT_PIN='2E28D8E0D7CAC1C938D369F714E8FF649BA7541F1527F8B17CB5A1EEA82A9362'
LEAF_PIN='1A69F04F3F5CF88230D48E56D6571EBAE0678FAF49E682FFFB0F5FB5EFE63329'
ED_PIN='D9026275A976F13D98777539AB635DD3EF48012E9D1BE6F1691205E1BCB7A7A9'
def configuration(policy_path,expected_policy_hash,platform,tool,expected_tool_hash,operator_sid=None):
 raw=read_regular(policy_path,1024*1024)
 require(sha(raw)==expected_policy_hash,'CONFIG_POLICY_PIN')
 p=strict_json(raw)
 require(set(p)=={'schema','product','version','minimum_release_generation','publisher','runtime_signers','verifier_files'},'CONFIG_POLICY_FIELDS')
 require(p['schema']=='odre-customer-verifier-policy/v1' and p['product']=='ODRE PQC Production' and p['version']=='0.3.0' and type(p['minimum_release_generation']) is int and p['minimum_release_generation']>=18,'CONFIG_POLICY_IDENTITY')
 pub=p['publisher'];require(pub.get('root_sha256')==ROOT_PIN and pub.get('leaf_sha256')==LEAF_PIN and pub.get('eku')=='1.3.6.1.4.1.311.10.3.12','CONFIG_PUBLISHER_AUTHORITY')
 require(set(p['runtime_signers'])=={'WINDOWS_SERVER_2022','UBUNTU_24_04'},'CONFIG_RUNTIME_PLATFORMS')
 for signer in p['runtime_signers'].values():
  require(signer=={'key_id':ED_PIN[:24],'public_sha256':ED_PIN},'CONFIG_RUNTIME_AUTHORITY')
 require(isinstance(p['verifier_files'],dict) and p['verifier_files'],'CONFIG_VERIFIER_FILES')
 for name,digest in p['verifier_files'].items():
  require(re.fullmatch(r'[A-Za-z0-9_.-]+',name) and name not in ('.','..'),'CONFIG_VERIFIER_PATH')
  require(sha(read_regular(policy_path.parent/name,1024*1024))==digest,'CONFIG_VERIFIER_PIN')
 require(tool.is_absolute() and re.fullmatch(r'[0-9A-F]{64}',expected_tool_hash),'CONFIG_TOOL_INPUT')
 require(sha(read_regular(tool,64*1024*1024))==expected_tool_hash,'CONFIG_TOOL_PIN')
 result={k:p[k] for k in ('product','version','minimum_release_generation','publisher','runtime_signers')}
 result['schema']='odre-production-bootstrap-trust/v1'
 backend={'executable':str(tool),'executable_sha256':expected_tool_hash}
 if platform=='windows':
  require(tool.name.casefold()=='powershell.exe','CONFIG_WINDOWS_TOOL')
  require(isinstance(operator_sid,str) and re.fullmatch(r'S-1-5-21-\d+-\d+-\d+-\d+',operator_sid),'CONFIG_OPERATOR_SID')
  require(all(n in p['verifier_files'] for n in ('Verify-DetachedCms.ps1','Check-InstallParent.ps1')),'CONFIG_WINDOWS_HELPERS')
  backend.update(helper='Verify-DetachedCms.ps1',helper_sha256=p['verifier_files']['Verify-DetachedCms.ps1'])
  result['cms_backends']={'windows':backend}
  result['install']={'windows':{'operator_sid':operator_sid,'parent_acl_helper':'Check-InstallParent.ps1','parent_acl_helper_sha256':p['verifier_files']['Check-InstallParent.ps1']}}
 else:
  require(platform=='ubuntu' and tool.name=='openssl' and operator_sid is None,'CONFIG_UBUNTU_TOOL')
  result['cms_backends']={'linux':backend}
 return result

def main():
 a=argparse.ArgumentParser(description=__doc__)
 a.add_argument('--policy',type=Path,required=True);a.add_argument('--policy-sha256',required=True)
 a.add_argument('--platform',choices=['windows','ubuntu'],required=True)
 a.add_argument('--cms-tool',type=Path,required=True);a.add_argument('--cms-tool-sha256',required=True)
 a.add_argument('--operator-sid');a.add_argument('--output',type=Path,required=True)
 x=a.parse_args()
 try:
  # Certificate and helper paths are relative to this directory in cms_gate.
  require(x.output.absolute().parent==x.policy.absolute().parent,'CONFIG_OUTPUT_DIRECTORY')
  v=configuration(x.policy.absolute(),x.policy_sha256.upper(),x.platform,x.cms_tool,x.cms_tool_sha256.upper(),x.operator_sid)
  raw=json.dumps(v,sort_keys=True,separators=(',',':')).encode()
  with x.output.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
  require(read_regular(x.output,1024*1024)==raw,'CONFIG_WRITE_READBACK')
  print(json.dumps({'LOCAL_VERIFIER_CONFIGURATION':'PREPARED','trust_sha256':sha(raw),'cms_tool_executed':0,'product_executed':0,'identity_state_changed':0,'production_contact':0}))
  return 0
 except (IntegrityError,OSError):
  print(json.dumps({'LOCAL_VERIFIER_CONFIGURATION':'FAIL','product_executed':0,'production_contact':0}))
  return 2
if __name__=='__main__':raise SystemExit(main())
