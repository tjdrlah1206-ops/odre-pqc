"""Read-only inventory for interrupted ODRE verified-install staging.

This module deliberately does not delete anything. An older interrupted
installer has no durable ownership lease, so automatic deletion cannot prove
that another installer is not using the directory.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import stat
from pathlib import Path


STAGING_NAME = re.compile(r"\.odre-verified-[0-9a-f]{32}\Z")
MAX_CANDIDATES = 256
MAX_ENTRIES_PER_CANDIDATE = 100_000
FILE_ATTRIBUTE_REPARSE_POINT = 0x400


def _is_reparse(path: Path) -> bool:
    metadata = path.lstat()
    return bool(getattr(metadata, "st_file_attributes", 0) & FILE_ATTRIBUTE_REPARSE_POINT)


def _inventory(candidate: Path) -> dict:
    if _is_reparse(candidate) or candidate.is_symlink() or candidate.is_junction():
        return {"name": candidate.name, "status": "REVIEW_REPARSE_POINT"}
    if not candidate.is_dir():
        return {"name": candidate.name, "status": "REVIEW_NOT_DIRECTORY"}
    files = 0
    directories = 1
    bytes_total = 0
    pending = [candidate]
    entries_seen = 0
    while pending:
        directory = pending.pop()
        with os.scandir(directory) as entries:
            for entry in entries:
                entries_seen += 1
                if entries_seen > MAX_ENTRIES_PER_CANDIDATE:
                    return {"name": candidate.name, "status": "REVIEW_INVENTORY_LIMIT"}
                metadata = entry.stat(follow_symlinks=False)
                if entry.is_symlink() or bool(getattr(metadata, "st_file_attributes", 0) & FILE_ATTRIBUTE_REPARSE_POINT):
                    return {"name": candidate.name, "status": "REVIEW_REPARSE_POINT"}
                if stat.S_ISDIR(metadata.st_mode):
                    directories += 1
                    pending.append(Path(entry.path))
                elif stat.S_ISREG(metadata.st_mode):
                    files += 1
                    bytes_total += metadata.st_size
                else:
                    return {"name": candidate.name, "status": "REVIEW_SPECIAL_FILE"}
    return {
        "name": candidate.name,
        "status": "LEGACY_OWNERSHIP_UNPROVEN",
        "files": files,
        "directories": directories,
        "bytes": bytes_total,
    }


def inspect_staging(parent: Path) -> list[dict]:
    parent = parent.absolute()
    if not parent.is_dir() or parent.is_symlink() or parent.is_junction() or _is_reparse(parent):
        raise RuntimeError("STAGING_PARENT_INVALID")
    candidates = sorted(
        (entry for entry in parent.iterdir() if STAGING_NAME.fullmatch(entry.name)),
        key=lambda entry: entry.name,
    )
    if len(candidates) > MAX_CANDIDATES:
        raise RuntimeError("STAGING_CANDIDATE_LIMIT")
    return [_inventory(candidate) for candidate in candidates]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent", required=True, type=Path)
    args = parser.parse_args()
    try:
        items = inspect_staging(args.parent)
        print(json.dumps({
            "status": "PASS",
            "parent": str(args.parent.absolute()),
            "candidates": items,
            "candidate_count": len(items),
            "automatic_cleanup": False,
            "reason": "OWNERSHIP_AND_ACTIVE_USE_CANNOT_BE_PROVEN_FOR_LEGACY_STAGING",
        }, sort_keys=True, separators=(",", ":")))
        return 0
    except Exception as error:
        print(json.dumps({"status": "FAIL", "error": str(error)},
                         sort_keys=True, separators=(",", ":")))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
