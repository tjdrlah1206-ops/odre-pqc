[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ContentPath,
    [Parameter(Mandatory=$true)][string]$SignaturePath,
    [Parameter(Mandatory=$true)][string]$ExpectedSignerSha256
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
try {
    Add-Type -AssemblyName System.Security
    $content = [IO.File]::ReadAllBytes($ContentPath)
    $signature = [IO.File]::ReadAllBytes($SignaturePath)
    $info = [Security.Cryptography.Pkcs.ContentInfo]::new($content)
    $cms = [Security.Cryptography.Pkcs.SignedCms]::new($info, $true)
    $cms.Decode($signature)
    if ($cms.SignerInfos.Count -ne 1) { throw 'CMS_SIGNER_COUNT' }
    $signer = $cms.SignerInfos[0]
    $hasher = [Security.Cryptography.SHA256]::Create()
    try { $fingerprint = [BitConverter]::ToString($hasher.ComputeHash($signer.Certificate.RawData)).Replace('-', '') }
    finally { $hasher.Dispose() }
    if ($fingerprint -cne $ExpectedSignerSha256) { throw 'CMS_SIGNER_PIN' }
    if ($signer.DigestAlgorithm.Value -ne '2.16.840.1.101.3.4.2.1') { throw 'CMS_DIGEST_POLICY' }
    # Only the cryptographic signature is checked here. The independent Python
    # gate checks exact root/leaf pins, certificate EKU/validity and signed CRL.
    $cms.CheckSignature($true)
    @{ signature_valid=$true; signer_sha256=$fingerprint } | ConvertTo-Json -Compress
    exit 0
} catch {
    Write-Output '{"signature_valid":false,"error":"CMS_SIGNATURE_REJECTED"}'
    exit 2
}
